﻿using System.Web;
using System.Web.Mvc;

namespace IP_Address_Blocker
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}

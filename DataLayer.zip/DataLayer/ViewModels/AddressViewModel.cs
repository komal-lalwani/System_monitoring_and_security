﻿using DataLayer.Models;
using System.Collections.Generic;

namespace DataLayer.ViewModels
{
    public class AddressViewModel
    {
        public IpAddress IpAddress { get; set; }
        public List<IpAddress> AddressList { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class IpHistory
    {
        public int IpHistoryId { get; set; }
        public string IpAddress { get; set; }
        public string Status { get; set; }
        public DateTime RequestTime { get; set; }
    }
}

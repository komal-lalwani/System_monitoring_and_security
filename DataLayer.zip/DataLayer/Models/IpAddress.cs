﻿using System.ComponentModel.DataAnnotations;

namespace DataLayer.Models
{
    public class IpAddress
    {
        public int IpAddressId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Address { get; set; }
    }
}

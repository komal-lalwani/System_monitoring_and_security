﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class DbConnector : DbContext
    {
        public DbConnector() : base("IPBlocker")
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<IpAddress> IpAddress { get; set; }
        public DbSet<IpHistory> History { get; set; }

        public IpAddress GetIpAddressById(int value)
        {
            IpAddress bankAccount = null;
            try
            {
                bankAccount = IpAddress.Where(x => x.IpAddressId == value).FirstOrDefault();
            }
            catch (Exception ex)
            {
            }
            return bankAccount;
        }

        public List<IpAddress> GetIpAddresses()
        {
            List<IpAddress> accountsList = null;
            try
            {
                accountsList = IpAddress.ToList();
            }
            catch (Exception ex)
            {

            }
            return accountsList;
        }

        public bool SaveIpAddress(IpAddress ipAddress)
        {
            bool result = true;
            try
            {
                if (ipAddress.IpAddressId == 0)
                {
                    IpAddress.Add(ipAddress);
                }
                else
                {
                    Entry(ipAddress).State = EntityState.Modified;
                }
                SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public bool SaveIpHistory(IpHistory ipHistory)
        {
            bool result = true;
            try
            {
                History.Add(ipHistory);
                SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public bool IsValidIp(string ipAddress)
        {
            bool result = true;
            try
            {
                List<IpAddress> list = IpAddress.Where(x => x.Address == ipAddress).ToList();
                if(list != null && list.Count > 0)
                {
                    result = false;
                }
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public void DeleteIpAddress(int id)
        {
            try
            {
                IpAddress payment = IpAddress.Where(x => x.IpAddressId == id).FirstOrDefault();
                IpAddress.Remove(payment);
                SaveChanges();
            }
            catch (Exception ex)
            {

            }
        }

        public User IsValidUser(User user)
        {
            User validUser = null;
            try
            {
                List<User> result = Users.Where(x => x.Email == user.Email && x.Password == user.Password).ToList();
                if (result != null && result.Count > 0)
                {
                    validUser = result[0];
                }
            }
            catch (Exception ex)
            {

            }
            return validUser;
        }
    }
}
